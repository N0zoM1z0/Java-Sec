package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.PublishPointDaoPlus;

public class PublishPointDaoImpl implements PublishPointDaoPlus {

}
