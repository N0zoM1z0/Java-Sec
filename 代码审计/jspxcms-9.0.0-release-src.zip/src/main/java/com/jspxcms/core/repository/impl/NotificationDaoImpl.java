package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.NotificationDaoPlus;

public class NotificationDaoImpl implements NotificationDaoPlus {

}
