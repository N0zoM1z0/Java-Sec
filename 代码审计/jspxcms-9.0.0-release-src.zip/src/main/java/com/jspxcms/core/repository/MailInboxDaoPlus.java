package com.jspxcms.core.repository;

public interface MailInboxDaoPlus {

}
