package com.jspxcms.core.listener;

/**
 * MemberGroupDeleteListener
 * 
 * @author liufang
 * 
 */
public interface MemberGroupDeleteListener {
	public void preMemberGroupDelete(Integer[] ids);
}
