package com.jspxcms.core.listener;

/**
 * UserDeleteListener
 * 
 * @author liufang
 * 
 */
public interface SiteDeleteListener {
	public void preSiteDelete(Integer[] ids);
}
