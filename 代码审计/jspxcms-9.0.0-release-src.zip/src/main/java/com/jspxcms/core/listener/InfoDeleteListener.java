package com.jspxcms.core.listener;

/**
 * InfoDeleteListener
 * 
 * @author liufang
 * 
 */
public interface InfoDeleteListener {
	public void preInfoDelete(Integer[] ids);
}
