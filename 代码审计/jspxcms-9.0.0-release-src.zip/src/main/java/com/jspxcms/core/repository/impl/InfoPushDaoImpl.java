package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.InfoPushDaoPlus;

/**
 * Created by PONY on 2017/8/5.
 */
public class InfoPushDaoImpl implements InfoPushDaoPlus {
}
