package com.jspxcms.core.listener;

/**
 * WorkflowDeleteListener
 * 
 * @author liufang
 * 
 */
public interface WorkflowDeleteListener {
	public void preWorkflowDelete(Integer[] ids);
}
