package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.AttachmentRefDaoPlus;

public class AttachmentRefDaoImpl implements AttachmentRefDaoPlus {

}
