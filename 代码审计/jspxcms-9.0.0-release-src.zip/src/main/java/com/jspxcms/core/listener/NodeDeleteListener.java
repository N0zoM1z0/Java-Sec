package com.jspxcms.core.listener;

/**
 * NodeDeleteListener
 * 
 * @author liufang
 * 
 */
public interface NodeDeleteListener {
	public void preNodeDelete(Integer[] ids);
}
