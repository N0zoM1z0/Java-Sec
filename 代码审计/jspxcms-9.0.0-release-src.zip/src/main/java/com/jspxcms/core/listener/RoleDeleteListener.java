package com.jspxcms.core.listener;

/**
 * RoleDeleteListener
 * 
 * @author liufang
 * 
 */
public interface RoleDeleteListener {
	public void preRoleDelete(Integer[] ids);
}
