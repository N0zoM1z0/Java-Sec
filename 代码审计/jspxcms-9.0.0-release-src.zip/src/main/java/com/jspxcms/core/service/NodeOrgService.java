package com.jspxcms.core.service;

import com.jspxcms.core.domain.Node;

public interface NodeOrgService {
	public void update(Node node, Integer[] viewOrgIds);
}
