/**
 *  Redis serializer<p>
 *  Redis序列化器
 * 
 */
package com.publiccms.common.redis.serializer;