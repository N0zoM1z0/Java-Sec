/**
 *  Hibernate redis provider<p>
 *  Hibernate redis驱动
 * 
 */
package com.publiccms.common.redis.hibernate;