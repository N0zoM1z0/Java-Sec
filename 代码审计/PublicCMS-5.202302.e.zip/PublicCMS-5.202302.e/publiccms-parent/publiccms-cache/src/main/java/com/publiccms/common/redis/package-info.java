/**
 *  Redis cache<p>
 *  Redis缓存
 * 
 */
package com.publiccms.common.redis;