/**
 *  J2cache<p>
 *  鸡儿擦车
 * 
 */
package com.publiccms.common.j2cache;