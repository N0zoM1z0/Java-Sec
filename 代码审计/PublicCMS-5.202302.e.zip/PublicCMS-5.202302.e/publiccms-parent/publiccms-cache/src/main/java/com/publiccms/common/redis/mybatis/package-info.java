/**
 *  Mybatis redis cache<p>
 *  Mybatis redis缓存实现
 * 
 */
package com.publiccms.common.redis.mybatis;