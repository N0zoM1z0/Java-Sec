/**
 *  Dictionary reloader<p>
 *  词典重置
 * 
 */
package org.apache.lucene.analysis.cn.smart.hhmm;