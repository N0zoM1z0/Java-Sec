/**
 *  Annotation<p>
 *  注解
 * 
 */
package com.publiccms.common.annotation;