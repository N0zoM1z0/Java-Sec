/**
 *  Interface controller<p>
 *  接口控制器
 * 
 */
package com.publiccms.controller.api;