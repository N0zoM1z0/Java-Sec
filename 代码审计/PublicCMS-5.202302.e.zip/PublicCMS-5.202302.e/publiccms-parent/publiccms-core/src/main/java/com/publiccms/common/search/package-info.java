/**
 *  Fulltext search<p>
 *  全文搜索
 * 
 */
package com.publiccms.common.search;