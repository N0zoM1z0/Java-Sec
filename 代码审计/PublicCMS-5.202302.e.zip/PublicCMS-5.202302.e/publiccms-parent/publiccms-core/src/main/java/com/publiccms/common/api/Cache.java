package com.publiccms.common.api;

/**
 *
 * Cache
 * 
 */
public interface Cache {
    /**
     * 
     */
    void clear();
}