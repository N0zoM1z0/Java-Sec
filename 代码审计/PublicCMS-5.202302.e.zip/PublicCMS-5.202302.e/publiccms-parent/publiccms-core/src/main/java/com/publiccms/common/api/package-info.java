/**
 *  Api interface<p>
 *  api接口封装
 * 
 */
package com.publiccms.common.api;