/**
 *  Database<p>
 *  数据库
 * 
 */
package com.publiccms.common.database;