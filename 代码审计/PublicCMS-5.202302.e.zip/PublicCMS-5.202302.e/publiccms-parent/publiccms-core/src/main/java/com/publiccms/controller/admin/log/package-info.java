/**
 *  Cms log management controller<p>
 *  CMS日志管理后台控制器
 * 
 */
package com.publiccms.controller.admin.log;