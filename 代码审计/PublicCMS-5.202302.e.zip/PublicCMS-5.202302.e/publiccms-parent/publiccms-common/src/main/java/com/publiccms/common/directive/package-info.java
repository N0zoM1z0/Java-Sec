/**
 *  Directive<p>
 *  指令
 * 
 */
package com.publiccms.common.directive;