/**
 *  Document processing<p>
 *  文档处理
 * 
 */
package com.publiccms.common.document;