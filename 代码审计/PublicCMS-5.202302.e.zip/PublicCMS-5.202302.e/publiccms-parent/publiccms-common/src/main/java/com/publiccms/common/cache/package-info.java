/**
 *  Cache<p>
 *  缓存
 * 
 */
package com.publiccms.common.cache;