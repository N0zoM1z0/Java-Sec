/**
 *  Query handler,Page handler,Template directive handler<p>
 *  查询处理器、分页处理器，模板指令处理器
 * 
 */
package com.publiccms.common.handler;