/**
 *  Base<p>
 *  基类
 * 
 */
package com.publiccms.common.base;