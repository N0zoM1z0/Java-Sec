/**
 *  Constants<p>
 *  常量
 * 
 */
package com.publiccms.common.constants;