/**
 *  Source generator annotation<p>
 *  代码生成工具注解
 * 
 */
package com.publiccms.common.generator.annotation;