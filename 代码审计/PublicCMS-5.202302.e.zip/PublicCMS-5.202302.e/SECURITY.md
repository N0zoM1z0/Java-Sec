# Security Policy

## Supported Versions

which versions are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
|V5-develop| :white_check_mark: |
| develop | :white_check_mark: |
|   4.0   | :white_check_mark: |
|  V2019  | :white_check_mark: |

## Reporting a Vulnerability
Please report security issues to master@publiccms.com
