package com.wangjiangfei.entity;

import lombok.Data;

@Data
public class SaleData {

    private String date;
    private double saleTotal;
    private double purchasingTotal;

}
