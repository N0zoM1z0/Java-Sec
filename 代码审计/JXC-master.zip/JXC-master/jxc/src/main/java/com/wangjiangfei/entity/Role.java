package com.wangjiangfei.entity;

import lombok.Data;

@Data
public class Role {

  private Integer roleId;
  private String roleName;
  private String remarks;

}
