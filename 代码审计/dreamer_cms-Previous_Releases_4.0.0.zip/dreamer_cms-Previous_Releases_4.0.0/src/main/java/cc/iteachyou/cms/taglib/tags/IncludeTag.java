package cc.iteachyou.cms.taglib.tags;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import cc.iteachyou.cms.common.ExceptionEnum;
import cc.iteachyou.cms.entity.Theme;
import cc.iteachyou.cms.exception.CmsException;
import cc.iteachyou.cms.exception.XssAndSqlException;
import cc.iteachyou.cms.service.ThemeService;
import cc.iteachyou.cms.taglib.IParse;
import cc.iteachyou.cms.taglib.annotation.Attribute;
import cc.iteachyou.cms.taglib.annotation.Tag;
import cc.iteachyou.cms.taglib.utils.RegexUtil;
import cc.iteachyou.cms.utils.FileConfiguration;
import cc.iteachyou.cms.utils.StringUtil;

/**
 * Include标签解析
 * @author Wangjn
 * @version 1.0.0
 */
@Component
@Tag(beginTag="{dreamer-cms:include /}",endTag="{/dreamer-cms:include}",regexp="(\\{dreamer-cms:include[ \\t]+.*/\\})|(\\{dreamer-cms:include[ \\t]+.*\\}\\{/dreamer-cms:include\\})", attributes={
		@Attribute(name = "file",regex = "[ \t]+file=[\"\'].*?[\"\']"),
	})
public class IncludeTag implements IParse {
	
	@Autowired
	private ThemeService themeService;
	@Autowired
	private FileConfiguration fileConfiguration;

	@Override
	public String parse(String html) throws CmsException {
		Tag annotations = IncludeTag.class.getAnnotation(Tag.class);
		Attribute[] attributes = annotations.attributes();
		List<String> all = RegexUtil.parseAll(html, annotations.regexp(), 0);
		if(StringUtil.isBlank(all)) {
			return html;
		}
		String newHtml = html;
		
		String resourceDir = fileConfiguration.getResourceDir() + "templates/";
		Theme currentTheme = themeService.getCurrentTheme();
		String templatePath = currentTheme.getThemePath() + "/";
		String basePath = resourceDir + templatePath;
		for (int i = 0; i < all.size(); i++) {
			Map<String,Object> entity = new HashMap<String,Object>();
			String includeTag = all.get(i);
			for (Attribute attribute : attributes) {
				String condition = RegexUtil.parseFirst(includeTag, attribute.regex(), 0);
				if(StringUtil.isBlank(condition)) {
					continue;
				}
				String key = condition.split("=")[0];
				String value = condition.split("=")[1];
				key = key.trim();
				value = value.replace("\"", "").replace("\'", "");
				entity.put(key, value);
			}
			
			if(entity.keySet() != null && entity.keySet().size() > 0) {
				String file = entity.get("file").toString();
				
				if(file.contains("../") || file.contains("..\\")) {
					throw new XssAndSqlException(
							ExceptionEnum.XSS_SQL_EXCEPTION.getCode(),
							ExceptionEnum.XSS_SQL_EXCEPTION.getMessage(),
							"Include标签文件名疑似不安全，详情：" + file);
				}
				
				String path = basePath + file;
				File includeFile = new File(path);
				String includeHtml;
				try {
					includeHtml = FileUtils.readFileToString(includeFile, "UTF-8");
					newHtml = newHtml.replaceFirst(annotations.regexp(), includeHtml);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return newHtml;
	}

	@Override
	public String parse(String html, String params) {
		// TODO Auto-generated method stub
		return null;
	}

}
