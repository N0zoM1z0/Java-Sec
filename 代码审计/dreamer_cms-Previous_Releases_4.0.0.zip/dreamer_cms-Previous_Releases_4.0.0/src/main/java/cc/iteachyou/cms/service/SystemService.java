package cc.iteachyou.cms.service;

import cc.iteachyou.cms.entity.System;

public interface SystemService {

	System getSystem();

	int update(System system);

}
