package cc.iteachyou.cms.ueditor.define;

public enum ActionState {
	UNKNOW_ERROR
}
