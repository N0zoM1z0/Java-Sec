package cc.iteachyou.cms.exception;

public class AdminGeneralException extends CmsException {

	public AdminGeneralException(String code, String message, String reason) {
		super(code, message, reason);
	}
	
}
