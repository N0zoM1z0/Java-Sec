package cc.iteachyou.cms.dao;

import cc.iteachyou.cms.common.BaseMapper;
import cc.iteachyou.cms.entity.SearchRecord;

public interface SearchRecordMapper extends BaseMapper<SearchRecord> {
}