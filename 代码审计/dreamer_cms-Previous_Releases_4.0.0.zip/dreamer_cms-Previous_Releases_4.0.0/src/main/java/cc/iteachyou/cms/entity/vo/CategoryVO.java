package cc.iteachyou.cms.entity.vo;

import lombok.Data;

/**
 * 栏目扩展实体
 * @author 王俊南
 * Date: 2020-12-29
 */
@Data
public class CategoryVO {
	private String id;
	private String updateChild;
}
