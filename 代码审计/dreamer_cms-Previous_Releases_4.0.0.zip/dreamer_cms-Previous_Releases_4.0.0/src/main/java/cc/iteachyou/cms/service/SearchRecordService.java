package cc.iteachyou.cms.service;

import cc.iteachyou.cms.entity.SearchRecord;

public interface SearchRecordService {

	int add(SearchRecord sr);

}
