package org.syclover.srpingbootshiro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SrpingbootShiroApplicationTests {

    @Test
    void contextLoads() {
    }

}
