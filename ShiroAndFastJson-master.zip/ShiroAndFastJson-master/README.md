# ShiroAndFastJson

shiro加fastjson环境

# 说明
fastjson包下为各版本payload复现，来自https://github.com/kezibei/fastjson_payload。    
我在原项目基础上加了maven相关依赖，以及一点修改。   



web复现

路由访问:

/login 登录

/json json解析

/ser 反序列化

