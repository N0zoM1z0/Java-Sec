
The files in this directory are used as templates for the ant create-component target, please 
do not modify them without understanding the effect that it will have on that build target.