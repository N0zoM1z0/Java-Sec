# JNDI Injection Bypass
 Some payloads of JNDI Injection in JDK 1.8.0_191+
 
 https://www.cnblogs.com/Welk1n/p/11066397.html
 
 
 ### Contributions
Thanks [@orangetw](https://github.com/orangetw) for enhancing payload!
